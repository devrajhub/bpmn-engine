# Server-Driven Workflow Engine (BPMN 2.0) – Anonymized Sample

This is an anonymized, production-inspired Node.js/NestJS service that executes BPMN-style workflows and emits **server-driven UI descriptors**. The frontend renders screens based on **action keys + component schemas** returned by the engine, so product teams can change flows without redeploying the FE.

> Note: All environment values, company names, and external endpoints have been removed or generalized for sharing.

## Key Features
- **BPMN 2.0 inspired engine:** tasks, gateways, sequence flows
- **Server-driven UI:** engine returns `action_keys` + component descriptors to FE
- **Role/Policy checks (RBAC):** action gating at engine layer
- **Resilience:** retries, circuit breakers, timeouts
- **Observability hooks:** per-step metrics & SLA guardrails
- **Extensible adapters:** clean interfaces to call external services

## High-Level Architecture



# 1 Install deps
npm ci

# 2 Setup env
cp .env.example .env
# fill values (DB URI, PORT, etc.)

# 3 Run (dev)
npm run start:dev

# 4 Swagger
# http://localhost:<PORT>/docs
